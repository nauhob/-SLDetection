import kotlin.system.measureTimeMillis
import java.util.LinkedList

fun main(args: Array<String>) {
    val numbers = LinkedList(listOf(1, 2, 3, 4, 5))
    val enlargedNumbers = LinkedList<Int>()

    repeat(100000) {
        enlargedNumbers.add(it + 1)
    }

    val timeForLoop = measureTimeMillis {
        for (index in 0 until enlargedNumbers.size) {
            println("Number is ${enlargedNumbers[index]}")
        }
    }

    val timeForEachLoop = measureTimeMillis {
        enlargedNumbers.forEach { num ->
            println("Number is $num")
        }
    }

    println("Time for for loop: $timeForLoop ms")
    println("Time for foreach loop: $timeForEachLoop ms")
}