import kotlin.system.measureTimeMillis
import kotlin.collections.copyOf

fun main(args: Array<String>){
    val numbers = arrayOf(1, 2, 3, 4, 5)
    val enlargedNumbers = numbers.copyOf(100000)

    val timeForLoop = measureTimeMillis {
        for (index in enlargedNumbers.indices) {
            println("Number is ${enlargedNumbers[index]}")
        }
    }

    val timeForEachLoop = measureTimeMillis {
        enlargedNumbers.forEach { num ->
            println("Number is $num ")
        }
    }

    println("Time for for loop: $timeForLoop ms")
    println("Time for foreach loop: $timeForEachLoop ms")
}