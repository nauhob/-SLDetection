//package testtttttt;
//
//import com.github.javaparser.JavaParser;
//import com.github.javaparser.ast.CompilationUnit;
//import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
//import com.github.javaparser.ast.body.MethodDeclaration;
//import com.github.javaparser.ast.body.TypeDeclaration;
//import com.github.javaparser.ast.expr.EnclosedExpr;
//import com.github.javaparser.ast.expr.MethodCallExpr;
//import com.github.javaparser.ast.type.TypeParameter;
//import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
//
///**
// * @author shkstart
// * @create 2021-10-15-11:31
// */
//public class JavaParseTest {
//    public static void parseJavaCode(){
//        String javaCode = "public class Test {\n" +
//                "    \n" +
//                "    public void x(){\n" +
//                "        System.out.println(\"just soso\");\n" +
//                "    }\n" +
//                "    \n" +
//                "    public static void y(){\n" +
//                "        System.out.println(\"i don't know\");\n" +
//                "    }\n" +
//                "    \n" +
//                "    public static void main(String[] args) {\n" +
//                "        int x = Integer.parseInt(args[0]);\n" +
//                "        System.out.println(\" sign (x) is : \" + sign(x));\n" +
//                "    }\n" +
//                "\n" +
//                "    private static int sign(int x){\n" +
//                "        if(x > 0){\n" +
//                "            return 1;\n" +
//                "        }else if(x < 0){\n" +
//                "            return -1;\n" +
//                "        }else return 0;\n" +
//                "    }\n" +
//                "}";
//
//        CompilationUnit result = JavaParser.parse(javaCode);
//        VoidVisitorAdapter<Object> adapter = new VoidVisitorAdapter<Object>() {
//
//
//
//            @Override
//            public void visit(EnclosedExpr n, Object arg) {
//                super.visit(n, arg);
//            }
//
//            @Override
//            public void visit(ClassOrInterfaceDeclaration n, Object arg) {//ClassOrInterfaceDeclaration：获取类名
//                super.visit(n, arg);
//                //
//                System.out.println("----------111---------------");
//                System.out.println(n.getName().getIdentifier());
//                System.out.println("----------111---------------");
//            }
//
//            @Override
//            public void visit(MethodCallExpr n, Object arg) { //MethodCallExpr：按照代码执行的先后获取所有使用的方法
//                super.visit(n, arg);
//                //
//                System.out.println("----------222---------------");
//                System.out.println(n.getName().getIdentifier());
//                System.out.println("----------222---------------");
//            }
//
//            @Override
//            public void visit(MethodDeclaration n, Object arg) { //MethodDeclaration:获取所有声明的方法？
//                super.visit(n, arg);
//                //
//                System.out.println("------------333--------------");
//                System.out.println(n.getName().getIdentifier());
//                System.out.println("------------333--------------");
//            }
//
//
////            public void visit(TypeDeclaration n,Object arg){
////
////            }
//
//            @Override
//            public void visit(TypeParameter n, Object arg) {
//                super.visit(n, arg);
//
//                System.out.println(n.getName().getIdentifier());
//            }
//        };
//        adapter.visit(result,null);
//
//    }
//
//    public static void main(String[] args) {
//        parseJavaCode();
////        String offerCodes = "1,2,,,";
////        System.out.println(offerCodes);
////        String[] offerCodeString = offerCodes.split(",");  //就是去掉原字符串中的，
////        System.out.println(offerCodeString[1]+" "+offerCodeString[2]);
//
//    }
//}
