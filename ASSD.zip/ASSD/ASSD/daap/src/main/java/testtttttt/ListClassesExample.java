package testtttttt;

import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.parse.MyDpvdVisitor;
import com.daap.util.DirExplorer;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseException;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.visitor.GenericVisitor;
import com.github.javaparser.ast.visitor.VoidVisitor;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import sun.security.util.AuthResources_it;

import java.io.File;
import java.io.IOException;
import java.security.Signature;
import java.util.*;

/**
 * @author shkstart
 * @create 2022-01-12-21:21
 */
public class ListClassesExample {

    static Map<Node,Node> variableMap = new HashMap<Node,Node>();
    static List<MethodDeclaration> methodNode = new ArrayList<MethodDeclaration>();


    public static void main(String[] args) {
        File dir = new File("D:\\programme\\eclipse\\code\\code2-Arreytest\\src\\arreytest\\1");
//        test(file);

        Map<String,String> map = new HashMap<>();
        map.put("111","a");
        map.put("222","b");
        map.put("111","c");
        Map<String, Integer> map2;

        String method1 = "123";//不可以变（不可以增删改）
        String method2 = "456";
        StringBuilder sb = new StringBuilder(); //可以变（可以增删
        sb.append(method1);
        sb.append(method2);
        sb.toString();

        System.out.println(dir);
        new DirExplorer((level, path, file) -> path.endsWith(".java"), (level, path, file) -> {
            try {

                new VoidVisitorAdapter<Object>() {


                    @Override
                    public void visit(MethodDeclaration n, Object arg) {
//                        super.visit(n, arg);

                        System.out.println(n);

                    }
                }.visit(JavaParser.parse(file), null);
            }catch (IOException e) {
                new RuntimeException(e);
            }

        }).explore(dir);

    }

    public static void test(File projectDir){
        new DirExplorer((level, path, file) -> path.endsWith(".java"), (level, path, file) -> {
            try {

                new VoidVisitorAdapter<Object>() {


                    @Override
                    public void visit(MethodDeclaration n, Object arg) {
                        super.visit(n, arg);

                        System.out.println(n);

                    }
                }.visit(JavaParser.parse(file), null);
            }catch (IOException e) {
                new RuntimeException(e);
            }

        }).explore(projectDir);

    }

    public void listClasses(File projectDir, List arrayList) {

        new DirExplorer((level, path, file) -> path.endsWith(".java"), (level, path, file) -> {
//            System.out.println(path);
//            System.out.println("=============");
            try {

                new VoidVisitorAdapter<Object>() {


//                    @Override
//                    public void visit(FieldDeclaration n, Object arg) {
//                        super.visit(n, arg);
//                        System.out.println(n);
//                    }

                    @Override
                    public void visit(MethodDeclaration n, Object arg) {
                        super.visit(n, arg);
                        methodNode.add(n);
//                        System.out.println(n.containsWithin());
                        System.out.println(n.getName());
                        System.out.println(n.getBody().get().getStatements().isEmpty());
//                        System.out.println(n);
//                        if(n.getAnnotations().size() != 0){
//                            for(int i = 0; i < n.getAnnotations().size(); i++){
//                                if("@Override".equals(n.getAnnotations().get(i).toString())){
//                                    System.out.println("this is override");
//                                }
//                            }
//                        }
                    }

                    @Override
                    public void visit(VariableDeclarator n, Object arg) {
                        super.visit(n, arg);
                        variableMap.put(n.getChildNodes().get(1), n.getChildNodes().get(0));

                    }

                    @Override
                    public void visit(MethodCallExpr n, Object arg) {
                        super.visit(n, arg);
//                        System.out.println(n);
//                        System.out.println(n.getParentNodeForChildren());

                    }

                    //
//                    @Override
//                    public void visit(ClassOrInterfaceDeclaration n, Object arg) {
//                        super.visit(n, arg);
////                        arrayList.add(n.getName());  //类名
//                        if(!n.getMethodsByName("testMethod").isEmpty()){
//                            System.out.println("+++");
//                            System.out.println(n.getMethodsByName("testMethod"));
//                        }
//
////                        System.out.println(n.getExtendedTypes()); //类的继承对象
////                        System.out.println(n.getAllContainedComments());   // 类里面的注释掉的部分
////                        System.out.println(n.getFields());  //类成员的 变量类型 变量名  和 赋值
////                        System.out.println(n.getMembers()); // 每一种变量、方法的全部内容 算一个部分
////                        System.out.println(n.getCallablesWithSignature(new Signature()));
////                        System.out.println(n.getChildNodes()); //包括类名，成员变量声明赋值，函数及函数内容
////                        System.out.println(" * " + n.getName());
//                    }

                }.visit(JavaParser.parse(file), null);

                System.out.println(); // empty line
            } catch (IOException e) {
                new RuntimeException(e);
            }
        }).explore(projectDir);
    }

    public static void listMethodCalls(File projectDir) {
        new DirExplorer((level, path, file) -> path.endsWith(".java"), (level, path, file) -> {
            System.out.println(path);
            System.out.println("===============");
            try {

//                new VoidVisitorAdapter<Object>(){
//
//                    @Override
//                    public void visit(FieldDeclaration n, Object arg) {
//                        super.visit(n, arg);
////                        System.out.println(n);  //只可以获得类成员变量的声明、赋值
////                        System.out.println(n.getVariables());  //成员变量名及赋值（无变量类型）
////                        System.out.println(n.getElementType()); //只有成员变量的类型
//                    }
//                }.visit(JavaParser.parse(file), null);



                new VoidVisitorAdapter<Object>(){
//                    @Override
//                    public void visit(MethodCallExpr n, Object arg) {
//                        super.visit(n, arg);
//                        System.out.println(n.get);
////                        String[] s = n.toString().split("\\.");  ///@@@@@
////                        System.out.println(s[0]); //@@@@
//
//                    }

//                    @Override
//                    public void visit(NameExpr n, Object arg) {
//                        super.visit(n, arg);
//                        System.out.println(n.getParentNodeForChildren());
//                    }


//                                        @Override
//                    public void visit(MethodDeclaration n, Object arg) {
//                        super.visit(n, arg);
////                        System.out.println(n.getName());  //获得函数名  ---@@@
////                        System.out.println(n.getBody().get().getStatements().toString());
////                       String s =  n.getBody().get().getStatements().toString();  //整个方法体
//                           System.out.println(n.containsWithin());
//
//                     }

                                        @Override
                    public void visit(VariableDeclarator n, Object arg) {
                        super.visit(n, arg);
                                            System.out.println(n.getChildNodes());
//                        System.out.println(n.getName() + "----"+n.getChildNodes().get(0) + "-----" +n.getChildNodes().get(1) );   //  全部变量的名字   ----@@@
//                        System.out.println(n.getType()); // 全部变量的变量类型  -----@@@
//                        System.out.println(n.getParentNodeForChildren());
                    }

//                    @Override      //只能扫描到 完整的变量声明创建对象  直接输出n时
//                    public void visit(VariableDeclarationExpr n, Object arg) {
//                        super.visit(n, arg);
////                        System.out.println(n);
//                        System.out.println(n.getVariables());  //只有变量的赋值，缺少了变量类型而已
////                        System.out.println(n.getElementType());  //只有变量的类型
////                        for(int i = 0; i < n.getAllContainedComments().size(); i++)
////                        System.out.println(n.get);
//                    }


                }.visit(JavaParser.parse(file), null);



//                new VoidVisitorAdapter<Object>() {
//
//
////                    visit
//
//                    //                    @Override
////                    public void visit(MethodCallExpr n, Object arg) {
////                        super.visit(n, arg);
////                        System.out.println(" [L " + n.getBegin() + "] " + n);
////                    }
//                }.visit(JavaParser.parse(file), null);

                System.out.println(); // empty line
            } catch (IOException e) {
                new RuntimeException(e);
            }
        }).explore(projectDir);
    }

//    public static void main(String[] args) {
//        File projectDir = new File("D:\\IdeaProjects\\ImageViewer\\src\\imageForFile");
//        List arrayList = new ArrayList<String>();
//        ListClassesExample l = new ListClassesExample();
//        l.listClasses(projectDir,arrayList);
//
//
//
////        l.listClasses(projectDir,arrayList);
////        for(Object key : l.variableMap.keySet()){
////            System.out.println("---00"+key.toString());
////            for (int i = 0; i < l.methodNode.size(); i++) {
////                if(methodNode.get(i).toString().contains(key.toString())){
////                    System.out.println(methodNode.get(i).getName()+"---"+key+"----"+l.variableMap.get(key));
////                }
////            }
////        }
//
//
////        listMethodCalls(projectDir);
//
////        for(int i = 0; i < arrayList.size(); i++){
////            System.out.println(arrayList.get(i));
////        }
////        MyDpvdVisitor myDpvdVisitor = new MyDpvdVisitor();
//
////        MyDpvdVisitor.listClasses(projectDir);
////        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
//////            System.out.println(legacyClass.getFieldDeclarations());  //只是成员变量的作用域，声明，赋值
//////            System.out.println(legacyClass.getMethodCallExprs());
////            System.out.println(legacyClass.getVariableDeclarators()); //没有变量类型而已，是整个类的变量--@@@
//////            System.out.println(legacyClass.getv);
//////            System.out.println(legacyClass.getVariableDeclarationExprs()); //具有完整的变量声明创造过程的才被录入
//////            System.out.println(legacyClass.getMethodDeclarations());
//////            System.out.println(legacyClass.getObjectCreationExprs()); //所有new
//////            System.out.println(legacyClass.getFieldAccessExprs()); //不懂是什么牛马
//////            System.out.println(legacyClass.getInnerInterfacesList());
////            System.out.println(legacyClass.getMethodDeclarations());
////        }
//
//    }
}
