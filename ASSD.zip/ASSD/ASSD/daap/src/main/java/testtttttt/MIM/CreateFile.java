package testtttttt.MIM;



import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author OXT
 * @version 2.0
 * @date 2022/3/30 17:39
 */
public class CreateFile {
    public static String fileName="createMyMIMData01.md";
    private static int i=0;
    public static void createMyMIMData(String context){
        {
            try {
                BufferedWriter out = new BufferedWriter(new FileWriter(fileName,true));
                out.flush();
                out.write(context);
                out.close();
//                System.out.println("yes");
            } catch (IOException e) {

            }

        }
    }
    public static void createMyMIMData_2(String context){
        {i++;

            try {
                BufferedWriter out = new BufferedWriter(new FileWriter("total-"+fileName,true));
                out.flush();
//                if (TestMIM.i==0){
//                    out.write("<table>\n");
//                }
//                out.write(context);
//                if (TestMIM.i==69){
//                    out.write("\n</table>\n\n");
//                }
                out.close();
//                System.out.println("yes");
            } catch (IOException e) {

            }

        }
    }
}
