package testtttttt.MIM.me;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.CreateFile;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.stmt.Statement;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Azhar on 9/21/2017.
 */
public class MIMDetectionEngine {
    private static final int DIT = 6;
    private static int total = 0;
    private static boolean isMIM = false;
    private static int ISMIM = 0;
    private static int NOTMIM = 0;
    public static String smell = "MIM";
    private static boolean isEmpty_Override_Static = false;

    private static ArrayList<MethodDeclaration> isMimList=new ArrayList<>();
    private static ArrayList<MethodDeclaration> notMimList=new ArrayList<>();

//    private static final String fileName = "Member Ignoring Method";
    public MIMDetectionEngine() {
    }

    private static void called_Filter1(MethodDeclaration methodDeclaration,ArrayList<MethodDeclaration> nonMIMsmellyArrayList,ArrayList<MethodDeclaration> isMIMsmellyArrayList){

        if(nonMIMsmellyArrayList.size()==0||isMIMsmellyArrayList.size()==0)
            return;
        int size=nonMIMsmellyArrayList.size();
        for (int i = 0; i < nonMIMsmellyArrayList.size(); i++) {
            for (Statement statement: methodDeclaration.getBody().get().getStatements()) {
//                System.out.println("size=="+size+"==state"+methodDeclaration.getBody().get().getStatements().size());
                //遍历non，这个method内有没有调用non方法
                if(statement.toString().contains(nonMIMsmellyArrayList.get(i).getName().toString())){
//                    System.out.println(statement.toString()+"====="+nonMIMsmellyArrayList.get(i).getName().toString());
                    nonMIMsmellyArrayList.add(methodDeclaration);
//                    size++;不能加了
                    isMIMsmellyArrayList.remove(methodDeclaration);
                    //这是一个从mim中移出来的method所以需要看看这个方法是不是在mim中有被调用
                    called_Filter2(nonMIMsmellyArrayList,isMIMsmellyArrayList ,methodDeclaration);

                    return;
                }

            }
        }

    }

    private static void called_Filter2(ArrayList<MethodDeclaration> nonMIMSmellyArrayList,ArrayList<MethodDeclaration> isMIMsmellyArrayList, MethodDeclaration methodDeclaration) {
        if(nonMIMSmellyArrayList.size()<=0||isMIMsmellyArrayList.size()<=0){
            return;
        }
        //判断每一个是MIM的方法是否调用当前noMIM
        for (int i = 0; i < isMIMsmellyArrayList.size(); i++) {
            for (Statement statement:isMIMsmellyArrayList.get(i).getBody().get().getStatements()) {
                if(statement.toString().contains(methodDeclaration.getNameAsString())){
                    //调用了则转移到noMIM
                    MethodDeclaration method_1=isMIMsmellyArrayList.get(i);
                    nonMIMSmellyArrayList.add(method_1);

                    isMIMsmellyArrayList.remove(method_1);
                    i--;//移走了，则后一个填补到当前这个来了，arraylist变小了,否则会跳过一个
                    called_Filter2(nonMIMSmellyArrayList,isMIMsmellyArrayList,method_1);
                    //递归调用继续寻找这个转换为nonMIM的方法是否有被其他MIM方法调用
                    break;
                }
            }
        }
    }


    private static boolean intersection(List<FieldDeclaration> allFields, NodeList<Statement> fieldsAccessList) {

        for (FieldDeclaration fieldDeclaration :allFields) {
            for (Statement statement : fieldsAccessList) {
                if (statement.toString().contains(fieldDeclaration.getVariable(0).getNameAsString())) {
//                    System.out.println(statement.toString()+"+++"+fieldDeclaration.getVariable(0).getNameAsString());
                    return true;
                }
            }
        }
        return false;
    }

    private static List<FieldDeclaration> getAllFields(LegacyClass legacyClass){
        List<FieldDeclaration> list=new ArrayList<>();
        //获取本类的属性
        list.addAll(legacyClass.getFieldDeclarations());
//        System.out.println(list);
        if(legacyClass.getClassOrInterfaceDeclaration().getExtendedTypes().size()!=0) {
//            System.out.println(legacyClass.getName() + "**parentClass**:\n" + legacyClass.getClassOrInterfaceDeclaration().getExtendedTypes().get(0).toString());
            for (LegacyClass lc : LegacySystem.getInstance().getAllClasses()) {
                if (lc.getName().equals(legacyClass.getClassOrInterfaceDeclaration().getExtendedTypes().get(0).toString())) {
                    //得到了父类，看看父类还有没有父类
                    list.addAll(getAllFields(lc));
                    return list;
                }
            }
        }
        return list;
    }

    private static boolean isNullMethod2(MethodDeclaration methodDeclaration) {
        try {
            if (methodDeclaration.getBody().get().getStatements().size()==0){
                return true;
            }else {
                return false;
            }
        }catch (Exception e){
            return true;
        }
    }




    public static void detect() {
//        XWPFDocument doc;
//        XWPFTable table;
//        doc = new XWPFDocument();
//        table = doc.createTable();
//        table.getRow(0).getCell(0).setText("Sr. No");
//        table.getRow(0).createCell().setText("Class");
////        table.getRow(0).createCell().setText("Method");
//        table.getRow(0).createCell().setText("Path");


//        ASD.clearConsole();
        ASD.writeMessage("M I M:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_MEMBER_IGNORING_METHOD);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        total = 0;  // check it.
        System.out.println("======================STARTED  MIM-------------------");


        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            isMIM = false;
            isEmpty_Override_Static = false;
            isMimList.clear();
            notMimList.clear();
            for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
//                if (methodDeclaration.isStatic()||isNullMethod2(methodDeclaration)||isOverride2(methodDeclaration)) {
//                    notMimList.add(methodDeclaration);
//                    continue;
//                }
                isMIM = false;
                isEmpty_Override_Static = false;

                if (methodDeclaration.isStatic()) {
                    isEmpty_Override_Static = true;
//                    NOTMIM++;
//                    continue;
                }
                //override方法
                boolean flag = false;
                if(methodDeclaration.getAnnotations().size() != 0){
                    for(int i = 0; i < methodDeclaration.getAnnotations().size(); i++){
                        if("@Override".equals(methodDeclaration.getAnnotations().get(i).toString())){
                            flag  = true;
                            break;
                        }
                    }
                }
                if(flag){
//                    NOTMIM++;
//                    continue;
                    isEmpty_Override_Static = true;
                }
                //空方法, getBody()之后得到的是一个Optional对象，如果为null，又直接get()，就会报异常
                if(methodDeclaration.getBody().isPresent()){//isPresent()方法判断Optional是否包含null值，True为不包含
                    if(methodDeclaration.getBody().get().getStatements().isEmpty()){
//                        NOTMIM++;
//                        continue;
                        isEmpty_Override_Static = true;
                    }
                }
                if(!isEmpty_Override_Static){
                    NodeList<Statement> fieldsAccessList = getFieldsAccessList(methodDeclaration);

                    boolean contains = false;
                    if(!intersection(getAllFields(legacyClass),fieldsAccessList)){
                        contains = true;
                        total++;
                        isMimList.add(methodDeclaration);
                        called_Filter1(methodDeclaration,notMimList,isMimList);
                        isMIM = true;
//                        total++;

                        //找到MIM
                        try {
                            CreateFile.createFile(methodDeclaration.clone().toString(),smell,ISMIM+"",isMIM);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        ISMIM++;

                        ASD.writeMessage("Class Name: " + legacyClass.getName()+"testtestest"
                                + "\nPath: " + legacyClass.getPath() + "\n"
                        );

                        Constants.setHmap(legacyClass.getPath(),Constants.A_MEMBER_IGNORING_METHOD);
                        boolean exists = true;
                        for (DetectedInstance detectedInstance: detectedInstances){
                            if (detectedInstance.getName().equals(legacyClass.getName())){
                                detectedInstance.increment();
                                exists = false;
                                break;
                            }
                        }
                        if (exists){
                            detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                        }
                        System.out.println("================||");
                        System.out.println("legacyClass: " + legacyClass.getName() + " methodDeclaration: " + methodDeclaration.getNameAsString());
                        System.out.println(legacyClass.getPath());
                        System.out.println("================||");

                        continue;
                    }

//                    outer:
//                    for (FieldDeclaration fieldDeclaration : legacyClass.getFieldDeclarations()) {
////                    System.out.println("fieldDeclaration: " +fieldDeclaration.getVariable(0).getNameAsString());
//                        inner:
//                        for (Statement statement : fieldsAccessList) {
//                            if (statement.toString().contains(fieldDeclaration.getVariable(0).getNameAsString())) {
//                                contains = true;
//                                System.out.println("found ");
//                                break outer;
//                            }
//                        }
//
////                    if (fieldsAccessList.contains(fieldDeclaration.getVariable(0).getNameAsString())) {
////                        contains = true;
////                        System.out.println("found ");
////                        break;
////                    }
//                    }

//                    if (!contains) {
//
////                        isMIM = true;
////                        total++;
//
//                        //找到MIM
//                        try {
//                            CreateFile.createFile(methodDeclaration.clone().toString(),smell,ISMIM+"",isMIM);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                        ISMIM++;
//
//                        ASD.writeMessage("Class Name: " + legacyClass.getName()+"testtestest"
//                                + "\nPath: " + legacyClass.getPath() + "\n"
//                        );
//
//                        Constants.setHmap(legacyClass.getPath(),Constants.A_MEMBER_IGNORING_METHOD);
//                        boolean exists = true;
//                        for (DetectedInstance detectedInstance: detectedInstances){
//                            if (detectedInstance.getName().equals(legacyClass.getName())){
//                                detectedInstance.increment();
//                                exists = false;
//                                break;
//                            }
//                        }
//                        if (exists){
//                            detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
//                        }
//                        System.out.println("================||");
//                        System.out.println("legacyClass: " + legacyClass.getName() + " methodDeclaration: " + methodDeclaration.getNameAsString());
//                        System.out.println(legacyClass.getPath());
//                        System.out.println("================||");
//
//                        break;
//                    }
                }

//                if (!isMIM){
                    notMimList.add(methodDeclaration);
                    try {
                        CreateFile.createFile(methodDeclaration.clone().toString(),smell, NOTMIM +"",isMIM);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    NOTMIM++;
//                }
            }


//            for (ObjectCreationExpr objectCreationExpr : legacyClass.getObjectCreationExprs()) {
//                System.out.println("legacyClass: "+legacyClass.getName()+" objectCreationExpr: "+objectCreationExpr.toString());
//            }
        }
        System.out.println("total:  ----------------------------------------MIM  " + total);
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();
//        Helper.writeFile(doc, "MemberIgnoringMethod");
        System.out.println("======================FINISHED   MIM-------------------");


        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);
//        dsfdsf

    }


    private static NodeList<Statement> getFieldsAccessList(MethodDeclaration methodDeclaration) {

//        System.out.println(methodDeclaration.getBody().get().getStatements().toString());
//        System.out.println(methodDeclaration.getChildNodes().toString());

        NodeList<Statement> statements = new NodeList<>();

        try {
            statements = methodDeclaration.getBody().get().getStatements();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return statements;

    }

//    private static  ArrayList<String> getFieldsAccessList(MethodDeclaration methodDeclaration){
//
//        ArrayList<String> result = new ArrayList<>();
//        methodDeclaration.accept(new VoidVisitorAdapter<Object>() {
//            @Override
//            public void visit(final FieldAccessExpr fieldAccessExpr, final Object arg) {
//                super.visit(fieldAccessExpr, arg);
//
//                result.add(fieldAccessExpr.getNameAsString());
//            }
//        }, null);
//
//        return result;
//    }
}
