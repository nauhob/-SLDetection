package com.daap.util;


import java.io.File;
//给定目录的情况下，探索所有的java文件
public class DirExplorer {
    public interface FileHandler {
        void handle(int level, String path, File file);
    }

    public interface Filter {//interface
        boolean interested(int level, String path, File file);
    }

    private FileHandler fileHandler;
    private Filter filter;

    public DirExplorer(Filter filter, FileHandler fileHandler) {
        this.filter = filter;
        this.fileHandler = fileHandler;
    }

    public void explore(File root) {
        explore(0, "", root);
    }

    private void explore(int level, String path, File file) {//3.2
        if (file.isDirectory()) { // split
            for (File child : file.listFiles()) {
                explore(level + 1, path + "/" + child.getName(), child);  //递归
            }
        } else {
            if (filter.interested(level, path, file)) {  //这两个是干嘛
                fileHandler.handle(level, path, file);
            }
        }
    }

}
