package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.MethodCallExpr;

import java.util.*;

/**
 * @author ZHUWEI
 * @create 2022-02-05-21:50
 */
public class FeatureEnvyDetectionEngine {
//    private static final int DIT = 6;
    private static int total = 0;
    //    private static final String fileName = "Feature Envy";

    public static void detect(){

        System.out.println("======================STARTED  FE-------------------");
        ASD.writeMessage("F E:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_FEATURE_ENVY);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();

        List<ClassOrInterfaceDeclaration> classDeclaration = new ArrayList<ClassOrInterfaceDeclaration>();  //������
        List<String> methodNam2e = new ArrayList<String>();  //���˷�����
        List<String> valueName = new ArrayList<String>();  //���˱�����
        List<String> valueCallName = new ArrayList<String>(); //���������� ʹ�ù��˵ı���������

        Map<Node,Node> variableMap = new HashMap<Node,Node>(); //����ȫ���ı����� �� ��������  ��Node����

//        Map<String,String> variableMap = new HashMap<String,String>();
        Map<Node,Node> variableMapTrue = new HashMap<Node,Node>(); //����ɸѡ֮��ı����� �� ��������
        Map<Node,Node> variableMapFinal = new HashMap<Node,Node>();
        List<MethodDeclaration> methodNode = new ArrayList<MethodDeclaration>(); //���˷�����MethodDeclaration���͵���ʽ��Ҫ������contains�����жϱ������ĸ�������
        List<LegacyClass> legacyClassList = new ArrayList<>();
        List<LegacyClass> legacyClassList2 = new ArrayList<>();

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            legacyClassList.add(legacyClass);
            classDeclaration.add(legacyClass.getClassOrInterfaceDeclaration());
            for(MethodCallExpr methodCallExpr : legacyClass.getMethodCallExprs()){
//                System.out.println(methodCallExpr);
                String[] s = methodCallExpr.toString().split("\\.");
                valueCallName.add(s[0]);
            }
            for(MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()){
                methodNode.add(methodDeclaration);
//                methodNam2e.add(methodDeclaration.getName().toString());
            }
            for(VariableDeclarator variableDeclarator : legacyClass.getVariableDeclarators()){
                variableMap.put(variableDeclarator.getChildNodes().get(1),variableDeclarator.getChildNodes().get(0));
            }
        }



        Set keySet = variableMap.keySet();
            for(Object key : keySet){
            Node value = variableMap.get(key);
    //            System.out.println(value);
            for(int i = 0; i < classDeclaration.size(); i++) {
                if(value.toString().equals(classDeclaration.get(i).getName().toString())){  //ȥ�������������Լ���������͵ı���
    //                    System.out.println(value);
                    valueName.add(value.toString());  //������Ҫ�õı�����
                    if(key instanceof Node && value instanceof Node){
                        variableMapTrue.put((Node) key,value); //������Ҫ�õı�����-��������
                    }
                }
            }
        }

        //�����õı�������ͬʹ���˵ı�����������ͳ��
        Set keySetTure = variableMapTrue.keySet();
        int total2;
            for(Object key : keySetTure) {
                for (int i = 0; i < legacyClassList.size(); i++) {
                    total2 = 0;
                    List<String> valueCallName3 = new ArrayList<String>();
                    for (MethodCallExpr methodCallExpr : legacyClassList.get(i).getMethodCallExprs()) {
                        String[] s = methodCallExpr.toString().split("\\.");
                        valueCallName3.add(s[0]);
                    }
                    //��������ı������÷���һ��Ū����ÿ����ı�������ȥͳ��,��������������ϣ���ʱ��ȷ��
                    for (int j = 0; j < valueCallName3.size(); j++) {
                        if (valueCallName3.get(j).equals(key.toString())) {
                            total2++;
                        }
                    }
                    if (total2 >= 7) {
                        System.out.println(total2 + "===" + key + "---" + variableMapTrue.get(key));

//                    variableMapFinal.put((Node) key,variableMapTrue.get(key));

//                    legacyClassList2.add(legacyClassList.get(i));//������а��������������ı���

                        for (MethodDeclaration methodDeclaration : legacyClassList.get(i).getMethodDeclarations()) {
                            if (methodDeclaration.toString().contains(key.toString())) {//�÷����д���������� ���������˴�����ȱ�㣬���ҵ�������һ�����ֵķ���
                                System.out.println(legacyClassList.get(i).getName() + ": " + methodDeclaration.getName() + "->" + variableMapTrue.get(key) + "---" + key);
                                //                            System.out.println(classDeclaration.get(j).get);
                                total++;
//                            flag = true;
                                ASD.writeMessage("Class Name: " + legacyClassList.get(i).getName() + "  :\nMethod name: "
                                        + methodDeclaration.getName() + " -> Class: " + variableMapTrue.get(key) + "\n"
                                );

                                Constants.setHmap(legacyClassList.get(i).getPath(), Constants.A_FEATURE_ENVY);
                                System.out.println(legacyClassList.get(i).getPath());
                                boolean exists = true;
                                for (DetectedInstance detectedInstance : detectedInstances) {
                                    if (detectedInstance.getName().equals(legacyClassList.get(i).getName())) {
                                        detectedInstance.increment();
                                        exists = false;
                                        break;
                                    }
                                }
                                if (exists) {
                                    detectedInstances.add(new DetectedInstance(legacyClassList.get(i).getName(), legacyClassList.get(i).getPath(), 1));
                                }
                                break;

                            }
                        }

//                        break;
                    }
                }
            }

//            for(int i = 0; i < valueCallName.size(); i++){
//                if(valueCallName.get(i).toString().equals(key.toString())){
//                    total2++;
//                }
//            }
//            System.out.println(total2+"==="+key+"---"+variableMapTrue.get(key));
//            if(total2 >= 7){
//                variableMapFinal.put((Node) key,variableMapTrue.get(key));
//            }

//        }
        //        System.out.println(variableMapFinal);

//        Set keySetFinal = variableMapFinal.keySet();
////            System.out.println(keySetFinal);
////            System.out.println();
//            System.out.println("����Feature Envy����:");
//            for(Object key : keySetFinal) {
//                boolean flag = false;
//
//                for (int m = 0; m < legacyClassList.size(); m++) {
//                    List<String> valueCallName2 = new ArrayList<String>();
//                    for (MethodCallExpr methodCallExpr : legacyClassList.get(m).getMethodCallExprs()) {
//                        String[] s = methodCallExpr.toString().split("\\.");
//                        valueCallName2.add(s[0]);
//                    }
//                    if (valueCallName2.contains(key.toString())) {//��ô�������Ǵ��������������
//                        for (MethodDeclaration methodDeclaration : legacyClassList.get(m).getMethodDeclarations()) {
//                            if (methodDeclaration.toString().contains(key.toString())) {//�÷����д����������
//                                System.out.println(legacyClassList.get(m).getName() + ": " + methodDeclaration.getName() + "->" + variableMapTrue.get(key) + "---" + key);
//                                //                            System.out.println(classDeclaration.get(j).get);
//                                total++;
//                                flag = true;
//                                ASD.writeMessage("Class Name: " + legacyClassList.get(m).getName() + "  :\nMethod name: "
//                                        + methodDeclaration.getName() + " -> Class: " + variableMapTrue.get(key) + "\n"
//                                );
//
//                                Constants.setHmap(legacyClassList.get(m).getPath(), Constants.A_FEATURE_ENVY);
//                                System.out.println(legacyClassList.get(m).getPath());
//                                boolean exists = true;
//                                for (DetectedInstance detectedInstance : detectedInstances) {
//                                    if (detectedInstance.getName().equals(legacyClassList.get(m).getName())) {
//                                        detectedInstance.increment();
//                                        exists = false;
//                                        break;
//                                    }
//                                }
//                                if (exists) {
//                                    detectedInstances.add(new DetectedInstance(legacyClassList.get(m).getName(), legacyClassList.get(m).getPath(), 1));
//                                }
//                                break;
//
//                            }
//                        }
//                    }
////                    if(flag){
////                        break;
////                    }
//                }
//            }


//            for (int i = 0; i < methodNode.size(); i++) {
//    //                System.out.println(methodNode.get(i));
//                    if(methodNode.get(i).toString().contains(key.toString())){
//    //                if (methodNode.get(i).toString().contains(key.toString()) ) { //����������⣬û���ñ����ͷ�����ȷƥ��
//        ////                    System.out.println(methodNode.get(i));
//                        for(int j = 0; j < classDeclaration.size(); j++){
//                            if(!(classDeclaration.get(j).getMethodsByName(methodNode.get(i).getName().toString()).isEmpty())){
//                                System.out.println(classDeclaration.get(j).getName()+": "+methodNode.get(i).getName()+"->"+variableMapTrue.get(key)+"---"+key);
//    //                            System.out.println(classDeclaration.get(j).get);
//                                total++;
//                                ASD.writeMessage("Class Name: " + classDeclaration.get(j).getName()+"  :\nMethod name: "
//                                        + methodNode.get(i).getName() +" -> Class: " + variableMapTrue.get(key) + "\n"
//                                );
//                                flag = true;
//                                for(int k = 0; k < legacyClassList.size(); k++){
//                                    if(legacyClassList.get(k).getClassOrInterfaceDeclaration().equals(classDeclaration.get(j))){
//                                        Constants.setHmap(legacyClassList.get(k).getPath(),Constants.A_FEATURE_ENVY);
//                                        System.out.println(legacyClassList.get(k).getPath());
//                                        boolean exists = true;
//                                        for (DetectedInstance detectedInstance: detectedInstances){
//                                            if (detectedInstance.getName().equals(legacyClassList.get(k).getName())){
//                                                detectedInstance.increment();
//                                                exists = false;
//                                                break;
//                                            }
//                                        }
//                                        if (exists){
//                                            detectedInstances.add(new DetectedInstance(legacyClassList.get(k).getName(), legacyClassList.get(k).getPath(), 1));
//                                        }
//                                        break;
//                                    }
//                                }
//                            }
//    //                        if(flag){
//    //                            break;
//    //                        }
//                        }
//                    }
//                    if(flag){
//                        System.out.println("}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}");
//                        break; //��֤��ֻʹ��һ�α���ȥ��ѯFE������ֻҪ����������������FE�ģ����ᱻ��ΪFE
//                    }

//                }
//        }

        System.out.println("zhuwezwzwzwzwzwzwzwzwzw77777777777777777777777777777777");
        System.out.println("total:----------------------------------FE " + total);
        System.out.println("zhuwezwzwzwzwzwzwzwzwzw77777777777777777777777777777777");
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();


        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);
    }
}
