@OXT
1.选择文件：JFilePick
2. MyDpvdVisitor.listClasses(new File(projectSrcFolder))对路径进行拆分出文件，并调用javaparse分析拆分出来的源代码文件。 
3.分析完后，路径里面的文件的各种坏味道出来了，通过各个DetectionEngine进行分离。
   

1.textarea内容导入到文件？或者

表格
className  MIM    LM   SFL   ...
相对路径     几个    几个

对选中的每种味道分类

每一种中的每一个路径在一个list

每种坏味道 统计相同的类出现次数 存入字典

通过字典写入表格


-----------------------------------------------------
检测出的一个坏味道 含有的类
classname:{MiIM:2,SFL:3,}
每个classname对应自己的字典不能用static
