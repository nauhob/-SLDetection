package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.CreateFile;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.stmt.*;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import java.util.ArrayList;

/**
 * @author ZHUWEI
 * @Description
 * @create 2022-09-24-16:01
 */
public class ComplexClassDetectionEngine {

    private static int total = 0;
    public static String smell = "CC";
    private static boolean isCC = false;
    private static int complexCount;
    private static int ISCC = 0;
    private static int NOTCC = 0;

    public static void detect() {
//        System.out.println("����������������������������������������");
        total = 0;
        ASD.writeMessage("Complex Class:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_COMPLEX_CLASS);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        System.out.println("======================STARTED-------------------");



        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            complexCount = 0;
            isCC = false;
            legacyClass.getClassOrInterfaceDeclaration().accept(new VoidVisitorAdapter<Object>() {


                /**
                 *
                 *  for���Ȧ���Ӷȼ�1
                 */
                @Override
                public void visit(ForeachStmt n, Object arg) {
                    super.visit(n, arg);
                    complexCount++;
                }
                @Override
                public void visit(ForStmt n, Object arg) {
                    super.visit(n, arg);
                    complexCount++;
                }

                /**
                 * if���Ȧ���Ӷ�+1
                 */
                @Override
                public void visit(IfStmt n, Object arg) {
                    super.visit(n, arg);
                    complexCount++;
                }

                /**
                 * try-catch��Ȧ���Ӷ�+1
                 */
                @Override
                public void visit(TryStmt n, Object arg) {
                    super.visit(n, arg);
                    complexCount++;
                }

                /**
                 * switch��Ȧ���Ӷ�+1
                 */
                @Override
                public void visit(SwitchEntryStmt n, Object arg) {
                    super.visit(n, arg);
                    complexCount++;
                }

                /**
                 * whileѭ�����Ȧ���Ӷ�+1
                 */
                @Override
                public void visit(WhileStmt n, Object arg) {
                    super.visit(n, arg);
                    complexCount++;
                }


            }, null);

            if(complexCount >= 30){
                isCC = true;
            }

            if(isCC){

                try {
                    CreateFile.createFile(legacyClass.toString(),smell,ISCC+"",isCC);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ISCC++;


                total++;
                //                    ASD.writeMessage("Class: " + legacyClass.getName());
                ASD.writeMessage("Class Name: " + legacyClass.getName()//ͨ����Ѱ��
                        + "\nPath: " + legacyClass.getPath() + "\n"
                );

                //����1
                //                    Constants.CNAME.add(legacyClass.getName());

                //                    Constants.setHmap(legacyClass.getName(),Constants.A_SLOW_FOR_LOOP);

                Constants.setHmap(legacyClass.getPath(),Constants.A_COMPLEX_CLASS);
                //                    Helper.writeDoc(table, legacyClass, total);
                //                    Constants.HMAPI["A_SLOW_FOR_LOOP"]
                System.out.println("legacyClass: " + legacyClass.getName() + " has Complex Class");
                boolean exists = true;
                for (DetectedInstance detectedInstance: detectedInstances){
                    if (detectedInstance.getName().equals(legacyClass.getName())){
                        detectedInstance.increment();
                        exists = false;
                        break;
                    }
                }
                if (exists){
                    detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                }
            }else{

                try {
                    CreateFile.createFile(legacyClass.toString(),smell,NOTCC+"",isCC);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                NOTCC++;

            }

        }


        System.out.println("total: " + total);
        ASD.writeMessage("Total: "+total);
        ASD.detectionDone();
//        Helper.writeFile(doc, "SlowForLoop");
        System.out.println("======================FINISHED-------------------");
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);

    }

}
